Hnias Runic Font

Copyright � 2004 Lars T�rnqvist

This font is free for personal use. The most recent version can be downloaded at www.thesauruslex.com.
